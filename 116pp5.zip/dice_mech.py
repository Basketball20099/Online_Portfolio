dice_roll = input("Roll the dice (Yes/No): ")
if dice_roll == "Yes":
  print("Rolling the dice...")
  import random
  dice_roll = random.randint(1, 6)
  print("You rolled a", dice_roll)
  if dice_roll == 1:
    print("You rolled a 1")
  if dice_roll == 2:
    print("You rolled a 2")
  if dice_roll == 3:
    print("You rolled a 3")
  if dice_roll == 4:
    print("You rolled a 4")
  if dice_roll == 5:
    print("You rolled a 5")
  if dice_roll == 6:
    print("You rolled a 6")
