def roll_dice():
  dice_roll = input("Roll the dice (Yes/No): ")
  if dice_roll == "Yes":
    print("Rolling the dice...")
    import random
    dice_roll = random.randint(1, 6)
    print("You rolled a", dice_roll)


answer = input("Would You Like to Play? (Yes/No) ")
if answer.lower().strip() == "yes":
  answer1 = "forest"
  answer2 = "mountain"
  answer3 = "fight"
  answer4 = "run"
  answer5 = "swim"
  answer6 = "keep walking"

  answer = input(
      "You reach a crossroads, you have the option to go into the forest or climb up the mountain? Do you choose forest or mountain: "
  ).lower().strip()
  if answer == answer1:
    answer = input(
        "You encountered a Troll!!! Would you like to fight or run: ")

    if answer == answer3:
      dice_roll = input("Roll the dice (Yes/No): ")
      if dice_roll == "yes":
        print("Rolling the dice...")
        import random
        dice_roll = random.randint(1, 6)
        print("You rolled a", dice_roll)
        if dice_roll == 1:
          print("You have summoned a monkey though the power of dice")
          print("The monkey ran away")
          print("It ate your head. You lose")
          quit()
        if dice_roll == 2:

          print("You have summoned a rusty sword though the power of dice")
          print("You fought cowardly and the rusty sword broke")
          print("It ate your head. You lose")
          quit()
        if dice_roll == 3:

          print("You have summoned a rusty sword though the power of dice")
          print("You fought cowardly and the rusty sword broke")
          print("It ate your head. You lose")
          quit()
        if dice_roll == 4:
          print("You have summoned a Sniper through the power of dice")
          print(
              "You used the sniper well and defeated the troll but in the proces you got hurt"
          )
        if dice_roll == 5:
          print("You have summoned a magical sword through the power of dice")
          print(
              "You fought valiently and defeateed the troll witth no injuries")
        if dice_roll == 6:
          print(
              "You have summoned a magical sword through the power of dice and have gotten buffs"
          )
          print(
              "You fought valiently and defeateed the troll witth no injuries")
          dice_roll = random.randint(2, 6)

    else:
      print("The troll was too slow. You maneuvered it.")

    answer = input(
        "You keep walking along the forest path. But then, you run into a giant spider. Would you like to fight or run: "
    )
    if answer == answer3:
      dice_roll = input("Roll the dice (Yes/No): ")
      if dice_roll == "yes":
        print("Rolling the dice...")
        import random
        dice_roll = random.randint(1, 6)
        print("You rolled a", dice_roll)
        if dice_roll == 1:
          print("You have summoned a monkey though the power of dice")
          print("The monkey ran away")
          print("It wrapped you and ate you slowly. You lose")

          quit()
        if dice_roll == 2:

          print("You have summoned a rusty sword though the power of dice")
          print("You fought cowardly and the rusty sword broke")
          print("It wrapped you and ate you slowly. You lose")
          quit()
        if dice_roll == 3:

          print("You have summoned a rusty sword though the power of dice")
          print("You fought cowardly and the rusty sword broke")
          print("It wrapped you and ate you slowly. You lose")
          quit()
        if dice_roll == 4:
          print("You have summoned a Sniper through the power of dice")
          print(
              "You used the sniper well and defeated the spider but in the proces you got hurt"
          )
        if dice_roll == 5:
          print("You have summoned a magical sword through the power of dice")
          print(
              "You fought valiently and defeated the spider with no injuries")
        if dice_roll == 6:
          print(
              "You have summoned a magical sword through the power of dice and have gotten buffs"
          )
          print(
              "You fought valiently and defeateed the spider witth no injuries"
          )
          dice_roll = random.randint(3, 6)

    elif answer == answer4:
      print(
          "You ran away from the spider, and back to the troll which decided that it wasn't going to let you run this time. You lose"
      )
      quit()
    elif answer != answer4 or answer3:
      print("invalid")
    answer = input(
        "You keep walking along the path, but then you come across a lake. Would you like to swim or keep walking: "
    )
    if answer == answer5:
      answer = input(
          "You swim into the lake and immediately come accross the Crab King. Do you want to talk or fight:"
      )
      if answer == answer3:
        dice_roll = input("Roll the dice (Yes/No): ")
        if dice_roll == "yes":
          print("Rolling the dice...")
          import random
          dice_roll = random.randint(1, 6)
          print("You rolled a", dice_roll)
          if dice_roll == 1:
            print("You have summoned a monkey though the power of dice")
            print("The monkey ran away")
            print("It turned you into human sushi. You lose")

            quit()
          if dice_roll == 2:

            print("You have summoned a rusty sword though the power of dice")
            print("You fought cowardly and the rusty sword broke")
            print("It turned you into human sushi. You lose")
            quit()
          if dice_roll == 3:

            print("You have summoned a rusty sword though the power of dice")
            print("You fought cowardly and the rusty sword broke")
            print("It turned you into human sushi. You lose")
            quit()
          if dice_roll == 4:
            print("You have summoned a Sniper through the power of dice")
            print(
                "You used the sniper well and defeated the crab but in the battle you got hurt"
            )
            print(
                "A portal opens up and sucks you in. You seam to have ended up back at home"
            )
            quit()
          if dice_roll == 5:
            print(
                "You have summoned a magical sword through the power of dice")
            print(
                "You fought valiently and defeated the crab with almost no injuries"
            )
            print(
                "A portal opens up and sucks you in. You seam to have ended up back at home"
            )
            quit()
          if dice_roll == 6:
            print(
                "You have summoned a magical sword through the power of dice and have gotten buffs"
            )
            print(
                "You fought valiently and defeated the crab with almost no injuries"
            )
            print(
                "A portal opens up and sucks you in. You seam to have ended up back at home"
            )
            quit()
            dice_roll = random.randint(3, 6)
      else:
        print("The Crab King can't talk. He eats you. You lose")
        quit()

    else:
      answer = input(
          "You keep walking and come back to the lake. This time you swim, you start to see land in the distance, but then you hear a noise. You turn around and see a leviathan, do you fight or swim:"
      )
      if answer == answer3:
        dice_roll = input("Roll the dice (Yes/No): ")
        if dice_roll == "yes":
          print("Rolling the dice...")
          import random
          dice_roll = random.randint(1, 6)
          print("You rolled a", dice_roll)
          if dice_roll == 1:
            print("You have summoned a monkey though the power of dice")
            print("The monkey ran away")
            print("It wrapped you and ate you slowly. You lose")
            quit()

          if dice_roll == 2:

            print("You have summoned a rusty sword though the power of dice")
            print("You fought cowardly and the rusty sword broke")
            print("It wrapped you and ate you slowly. You lose")
            quit()
          if dice_roll == 3:

            print("You have summoned a rusty sword though the power of dice")
            print("You fought cowardly and the rusty sword broke")
            print("It wrapped you and ate you slowly. You lose")
            quit()
          if dice_roll == 4:
            print("You have summoned a Sniper through the power of dice")
            print(
                "You used the sniper well but the leviathan was too much for you. You have died"
            )
            quit()
          if dice_roll == 5:
            print("You have summoned a magical bow through the power of dice")
            print(
                "You fought valiently and defeated the spider but your barely hanging on to your life"
            )

            print(
                "A portal opens up and sucks you in. You seam to have ended up back at home"
            )
            quit()
          if dice_roll == 6:
            print(
                "You have summoned a magical sword through the power of dice and have gotten buffs"
            )
            print(
                "You fought valiently and defeateed the leviathan with almost no injuries"
            )
            print(
                "A portal opens up and sucks you in. You seem to have ended up back at home"
            )
            quit()
            dice_roll = random.randint(3, 6)
      else:
        print(
            "You try to swim away, but the leviathan was faster. It eats you. You lose"
        )
        quit()

  elif answer == answer2:
    print("You slipped on a bannana peel and died")
    playagain = input("Would you like to play again? (yes/no): ")
  else:
    print("Invalid")
else:
  print("That's too bad!")
